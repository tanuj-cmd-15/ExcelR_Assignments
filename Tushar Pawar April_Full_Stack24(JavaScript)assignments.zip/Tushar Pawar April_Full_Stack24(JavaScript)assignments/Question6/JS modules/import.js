// main.js

import { add, subtract, multiply, divide } from './export.js';

console.log("Add: 2 + 3 =", add(2, 3)); // Output: Add: 2 + 3 = 5
console.log("Subtract: 5 - 2 =", subtract(5, 2)); // Output: Subtract: 5 - 2 = 3
console.log("Multiply: 3 * 4 =", multiply(3, 4)); // Output: Multiply: 3 * 4 = 12
console.log("Divide: 10 / 2 =", divide(10, 2)); // Output: Divide: 10 / 2 = 5